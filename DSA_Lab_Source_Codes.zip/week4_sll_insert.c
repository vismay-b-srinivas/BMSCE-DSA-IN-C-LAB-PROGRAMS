#include <stdio.h>
#include <stdlib.h>

struct Node {
    int data;
    struct Node *next;
};

struct Node *head = NULL;

struct Node* createNode(int val) {
    struct Node *newNode = (struct Node*)malloc(sizeof(struct Node));
    newNode->data = val;
    newNode->next = NULL;
    return newNode;
}

void createList() {
    int n, val, i;
    struct Node *temp = NULL, *newNode;
    printf("Enter number of nodes: ");
    scanf("%d", &n);
    for (i = 0; i < n; i++) {
        printf("Enter value %d: ", i + 1);
        scanf("%d", &val);
        newNode = createNode(val);
        if (head == NULL) {
            head = newNode;
            temp = head;
        } else {
            temp->next = newNode;
            temp = newNode;
        }
    }
}

void insertFirst() {
    int val;
    printf("Enter value to insert at beginning: ");
    scanf("%d", &val);
    struct Node *newNode = createNode(val);
    newNode->next = head;
    head = newNode;
}

void insertEnd() {
    int val;
    printf("Enter value to insert at end: ");
    scanf("%d", &val);
    struct Node *newNode = createNode(val);
    if (head == NULL) {
        head = newNode;
        return;
    }
    struct Node *temp = head;
    while (temp->next != NULL) {
        temp = temp->next;
    }
    temp->next = newNode;
}

void insertAtPos() {
    int val, pos, i;
    printf("Enter position: ");
    scanf("%d", &pos);
    printf("Enter value: ");
    scanf("%d", &val);

    if (pos == 1) {
        struct Node *newNode = createNode(val);
        newNode->next = head;
        head = newNode;
        return;
    }

    struct Node *temp = head;
    for (i = 1; i < pos - 1 && temp != NULL; i++) {
        temp = temp->next;
    }
    if (temp == NULL) {
        printf("Invalid position!\n");
    } else {
        struct Node *newNode = createNode(val);
        newNode->next = temp->next;
        temp->next = newNode;
    }
}

void display() {
    struct Node *temp = head;
    if (head == NULL) {
        printf("List is empty.\n");
        return;
    }
    printf("Linked List: ");
    while (temp != NULL) {
        printf("%d -> ", temp->data);
        temp = temp->next;
    }
    printf("NULL\n");
}

int main() {
    int ch;
    printf("1. Create  2. Insert First  3. Insert Pos  4. Insert End  5. Display  6. Exit\n");
    while (1) {
        printf("\nEnter choice: ");
        scanf("%d", &ch);
        switch (ch) {
            case 1: createList(); break;
            case 2: insertFirst(); break;
            case 3: insertAtPos(); break;
            case 4: insertEnd(); break;
            case 5: display(); break;
            case 6: exit(0);
            default: printf("Invalid choice!\n");
        }
    }
    return 0;
}
