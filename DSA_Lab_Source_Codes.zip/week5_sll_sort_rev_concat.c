#include <stdio.h>
#include <stdlib.h>

struct Node {
    int data;
    struct Node *next;
};

struct Node* createList() {
    int n, val, i;
    struct Node *head = NULL, *temp = NULL, *newNode;
    printf("Enter number of nodes: ");
    scanf("%d", &n);
    for (i = 0; i < n; i++) {
        printf("Enter value %d: ", i + 1);
        scanf("%d", &val);
        newNode = (struct Node*)malloc(sizeof(struct Node));
        newNode->data = val;
        newNode->next = NULL;
        if (head == NULL) {
            head = newNode;
            temp = head;
        } else {
            temp->next = newNode;
            temp = newNode;
        }
    }
    return head;
}

void display(struct Node *head) {
    struct Node *temp = head;
    if (head == NULL) {
        printf("Empty\n");
        return;
    }
    while (temp != NULL) {
        printf("%d -> ", temp->data);
        temp = temp->next;
    }
    printf("NULL\n");
}

void sortList(struct Node *head) {
    struct Node *i, *j;
    int t;
    for (i = head; i != NULL; i = i->next) {
        for (j = i->next; j != NULL; j = j->next) {
            if (i->data > j->data) {
                t = i->data;
                i->data = j->data;
                j->data = t;
            }
        }
    }
}

struct Node* reverseList(struct Node *head) {
    struct Node *prev = NULL, *curr = head, *next = NULL;
    while (curr != NULL) {
        next = curr->next;
        curr->next = prev;
        prev = curr;
        curr = next;
    }
    return prev;
}

struct Node* concatenate(struct Node *h1, struct Node *h2) {
    if (h1 == NULL)
        return h2;
    struct Node *temp = h1;
    while (temp->next != NULL) {
        temp = temp->next;
    }
    temp->next = h2;
    return h1;
}

int main() {
    struct Node *list1 = NULL, *list2 = NULL;

    printf("Create List 1:\n");
    list1 = createList();
    printf("List 1: ");
    display(list1);

    sortList(list1);
    printf("Sorted List 1: ");
    display(list1);

    list1 = reverseList(list1);
    printf("Reversed List 1: ");
    display(list1);

    printf("\nCreate List 2:\n");
    list2 = createList();
    printf("List 2: ");
    display(list2);

    list1 = concatenate(list1, list2);
    printf("Concatenated List: ");
    display(list1);

    return 0;
}
